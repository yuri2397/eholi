<?php

namespace App\Http\Controllers;

use App\Models\SchoolHasProfessor;
use Illuminate\Http\Request;

class SchoolHasProfessorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SchoolHasProfessor  $schoolHasProfessor
     * @return \Illuminate\Http\Response
     */
    public function show(SchoolHasProfessor $schoolHasProfessor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SchoolHasProfessor  $schoolHasProfessor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SchoolHasProfessor $schoolHasProfessor)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SchoolHasProfessor  $schoolHasProfessor
     * @return \Illuminate\Http\Response
     */
    public function destroy(SchoolHasProfessor $schoolHasProfessor)
    {
        //
    }
}
